<?php
/*
Plugin Name: JWT Secret Plugin
Description: JWT Secret Plugin that fetches dynamically and defines JWT Secret.
version: 1.0.0
*/
register_activation_hook(__FILE__, 'my_plugin_activation_check');

function my_plugin_activation_check()
{
    if (!is_plugin_active('jwt-authentication-for-wp-rest-api/jwt-auth.php')) {
        // Required plugin not activated
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('Sorry, but this plugin requires the JWT Authentication for WP REST API plugin to be installed and activated. Please activate the JWT Authentication for WP REST API plugin and try again.');
    }
}
add_action('after_setup_theme', 'add_jwt_secret');
function add_jwt_secret()
{
    $secret_key = bin2hex(random_bytes(32));

    // Define the JWT secret key constant
    define('JWT_AUTH_SECRET_KEY', $secret_key);
    define('JWT_AUTH_CORS_ENABLE', true);
}
/* add_action('rest_api_init', function () {
register_rest_route(
'jwt-secret-plugin/v1',
'/jwt-secret-key',
array(
'methods' => 'GET',
'callback' => 'get_jwt_secret_key',
)
);
});
function get_jwt_secret_key($request)
{
// Generate a 256-bit random key
$secret_key = bin2hex(random_bytes(32));
// Define the JWT secret key constant
define('JWT_AUTH_SECRET_KEY', $secret_key);
define('JWT_AUTH_CORS_ENABLE', true);
// Return the secret key in the response
return rest_ensure_response(
array(
'secret_key' => $secret_key,
'JWT_AUTH_SECRET_KEY' => JWT_AUTH_SECRET_KEY
)
);
} */
/* add_action('rest_api_init', function () {
register_rest_route(
'jwt-secret-plugin/v1',
'/jwt-secret-key',
array(
'methods' => 'POST',
'callback' => 'set_jwt_secret_key',
)
);
});
function set_jwt_secret_key($request)
{
$params = $request->get_json_params();
if (isset($params['secretKey'])) {
$secret_key = $params['secretKey'];
define('JWT_AUTH_SECRET_KEY', $secret_key);
define('JWT_AUTH_CORS_ENABLE', true);
return wp_send_json_success();
} else {
return wp_send_json_error(array('message' => 'Missing secretKey parameter'));
}
} */